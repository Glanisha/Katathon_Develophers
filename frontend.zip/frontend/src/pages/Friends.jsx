import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";

export const Friends = () => {
  const { token, user } = useAuth();
  const navigate = useNavigate();
  const [friendEmail, setFriendEmail] = useState("");
  const [friends, setFriends] = useState([]);

  const API_URL = "http://localhost:5000/api"; // update for deployment

  const fetchFriends = async () => {
    try {
      const res = await axios.get(`${API_URL}/friends/list`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setFriends(res.data || []);
    } catch (err) {
      console.error("Fetch Friends Error:", err.response?.data);
    }
  };

  const addFriend = async () => {
    if (!friendEmail.trim()) return;
    try {
      await axios.post(
        `${API_URL}/friends/add`,
        { friendEmail },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setFriendEmail("");
      fetchFriends();
    } catch (err) {
      alert(err.response?.data?.message || "Something went wrong");
    }
  };

  useEffect(() => {
    fetchFriends();
  }, []);

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-2xl font-bold mb-4">Friends</h2>

      <div className="flex gap-2 mb-4">
        <input
          type="email"
          placeholder="Friend's email"
          value={friendEmail}
          onChange={(e) => setFriendEmail(e.target.value)}
          className="flex-1 border p-2 rounded"
        />
        <button
          onClick={addFriend}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Add
        </button>
      </div>

      <div className="mb-4">
        <h3 className="text-lg font-semibold">Friends List</h3>
        {friends.length === 0 && <p className="text-gray-500">No friends yet.</p>}

        {friends.map((f) => (
          <div key={f._id} className="p-2 border rounded mt-2">
            <strong>{f.name}</strong> — {f.email}
          </div>
        ))}
      </div>

      <button
        onClick={() => navigate("/dashboard/map?showFriends=true")}
        className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
      >
        See Friends on Map
      </button>
    </div>
  );
};
